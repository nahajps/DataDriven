self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "dcdf6c8bf11a98d83853d9e2df540458",
    "url": "/ddp/index.html"
  },
  {
    "revision": "7cc18e66b75aac49cacb",
    "url": "/ddp/static/css/main.4301a9d4.chunk.css"
  },
  {
    "revision": "13f4e7d814d15556deec",
    "url": "/ddp/static/js/2.ca9d78b0.chunk.js"
  },
  {
    "revision": "7cc18e66b75aac49cacb",
    "url": "/ddp/static/js/main.422fbc81.chunk.js"
  },
  {
    "revision": "a8931f4321a28de4d1f3",
    "url": "/ddp/static/js/runtime~main.8d8f4589.js"
  }
]);